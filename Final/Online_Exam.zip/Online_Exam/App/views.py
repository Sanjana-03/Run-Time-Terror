from django.shortcuts import render,redirect
from .models import *
from .forms import *
import time
from django.http import HttpResponse
from django.contrib.auth import logout,authenticate
from django.contrib import messages

# Create your views here.

def index(request):
	return render(request,'index.html');

def loginstudent(request):
	if request.user.is_authenticated:
		return redirect('studenthome')
	if request.method == 'POST':
			username = request.POST.get('username')
			password = request.POST.get('password')
			user = Student.objects.filter(username=username, password=password)
			if len(user):
				return redirect('studenthome')
			else:
				messages.error(request, "Invalid username or password.")
	
	return render(request, 'loginstudent.html')

def logoutstudent(request):
	logout(request)
	return redirect('loginstudent')

def logoutadmin(request):
	logout(request)
	return redirect('loginadmin')

def studenthome(request):
	data=Quiz.objects.all()
	return render(request,'studenthome.html',context={"data":data})

def loginadmin(request):
	if request.method == 'POST':
			username = request.POST.get('username')
			password = request.POST.get('password')
			user = Admin.objects.filter(username=username, password=password)
			if len(user):
				return render(request,'adminhome.html')
			else:
				messages.error(request, "Invalid username or password.")
	
	return render(request, 'loginadmin.html')

def adminhome(request):
	return render(request,'adminhome.html')



def signup(request):
	form = StudentForm()
	if request.method == 'POST':
		form = StudentForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('loginstudent')
	context = {'form':form}
	return render(request, 'signup.html', context)



def ViewQuestions(request):
	data =Question.objects.all()
	return render(request,'viewquestions.html',context={'data':data})

def ViewQuizes(request):
	data =Quiz.objects.all()
	return render(request,'viewquizes.html',context={'data':data})

def AddQuestions(request):
	form=QuestionForm(request.POST or None)
	if form.is_valid():
		form.save()
		return redirect('addquestions')
	return render(request,'addquestions.html',context={'form':form})



def Attempt(request,pk):
	data =Question.objects.get(id=pk)
	form=AttemptForm(request.POST or None)
	if form.is_valid():
		form.save()
	return render(request,'exam.html',context={'form':form,'data':data})

def AddQuiz(request):
	form=QuizForm(request.POST or None)
	if form.is_valid():
		form.save()
		return redirect('addquiz')
	return render(request,'addquiz.html',context={'form':form})










