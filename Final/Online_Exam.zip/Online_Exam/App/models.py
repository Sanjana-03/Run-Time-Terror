from django.db import models

# Create your models here.
class Admin(models.Model):
	id=models.AutoField(primary_key=True)
	firstname=models.CharField(max_length=66)
	lastname=models.CharField(max_length=66)
	email=models.EmailField(max_length=66)
	username=models.CharField(max_length=66)
	password=models.CharField(max_length=66)

	def __str__(self):
		return self.firstname

class Student(models.Model):
	id=models.AutoField(primary_key=True)
	firstname=models.CharField(max_length=66)
	lastname=models.CharField(max_length=66)
	email=models.EmailField(max_length=66)
	username=models.CharField(max_length=66)
	password=models.CharField(max_length=66)

	def __str__(self):
		return self.firstname

class Quiz(models.Model):
	id=models.IntegerField(primary_key=True)
	name=models.CharField(max_length=55)
	admin_id=models.ForeignKey(Admin,on_delete=models.CASCADE)
	status=models.DateTimeField()

	def __str__(self):
		return self.name

class Question(models.Model):
	id=models.IntegerField(primary_key=True)
	quiz_id=models.ForeignKey(Quiz,on_delete=models.CASCADE)
	question=models.TextField()
	image_url=models.CharField(max_length=166,blank=True)
	option1=models.CharField(max_length=166,blank=True)
	option2=models.CharField(max_length=166,blank=True)
	option3=models.CharField(max_length=166,blank=True)
	option4=models.CharField(max_length=166,blank=True)
	answer=models.CharField(max_length=166)

class Attempt(models.Model):
	id=models.AutoField(primary_key=True)
	ans=models.CharField(max_length=166,blank=True)

