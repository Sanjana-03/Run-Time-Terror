from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('loginstudent/',views.loginstudent,name='loginstudent'),
    path('logoutstudent/',views.logoutstudent,name='logoutstudent'),
    path('studenthome/',views.studenthome,name='studenthome'),
    path('loginadmin/',views.loginadmin,name='loginadmin'),
    path('logoutadmin/',views.logoutadmin,name='logoutadmin'),
    path('adminhome/',views.adminhome,name='adminhome'),
    path('signup/',views.signup,name='signup'),
    path('questions/<str:pk>',views.ViewQuestions,name='que'),
    path('attempt/<str:pk>',views.Attempt,name='attempt'),
    path('addquiz/',views.AddQuiz,name='addquiz'),
    path('viewquestions/',views.ViewQuestions,name='viewquestions'),
    path('addquestions/',views.AddQuestions,name='addquestions'),
    path('viewquizes/',views.ViewQuizes,name='viewquizes'),

    
]